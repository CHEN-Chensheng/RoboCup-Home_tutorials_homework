#!/bin/bash

wget --mirror ftp://opt.uib.es/bagfiles/viso2_ros

