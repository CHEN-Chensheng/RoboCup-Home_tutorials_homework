# generated from catkin/cmake/template/order_packages.context.py.in
source_root_dir = "/home/chenshengchen/ros/workspace/roboCupHome_tutorial_ChenshengCHEN/src"
whitelisted_packages = "".split(';') if "" != "" else []
blacklisted_packages = "".split(';') if "" != "" else []
underlay_workspaces = "/opt/ros/kinetic".split(';') if "/opt/ros/kinetic" != "" else []
