#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/chenshengchen/ros/workspace/roboCupHome_tutorial_ChenshengCHEN/src-build/devel:$CMAKE_PREFIX_PATH"
export LD_LIBRARY_PATH="/home/chenshengchen/ros/workspace/roboCupHome_tutorial_ChenshengCHEN/src-build/devel/lib:$LD_LIBRARY_PATH"
export PATH="/opt/ros/kinetic/bin:/usr/lib/x86_64-linux-gnu/qt4/bin:/usr/bin:/home/chenshengchen/bin:/home/chenshengchen/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin"
export PKG_CONFIG_PATH="/home/chenshengchen/ros/workspace/roboCupHome_tutorial_ChenshengCHEN/src-build/devel/lib/pkgconfig:$PKG_CONFIG_PATH"
export PWD="/home/chenshengchen/ros/workspace/roboCupHome_tutorial_ChenshengCHEN/src-build"
export PYTHONPATH="/home/chenshengchen/ros/workspace/roboCupHome_tutorial_ChenshengCHEN/src-build/devel/lib/python2.7/dist-packages:$PYTHONPATH"
export ROSLISP_PACKAGE_DIRECTORIES="/home/chenshengchen/ros/workspace/roboCupHome_tutorial_ChenshengCHEN/src-build/devel/share/common-lisp"
export ROS_PACKAGE_PATH="/home/chenshengchen/ros/workspace/roboCupHome_tutorial_ChenshengCHEN/src:$ROS_PACKAGE_PATH"