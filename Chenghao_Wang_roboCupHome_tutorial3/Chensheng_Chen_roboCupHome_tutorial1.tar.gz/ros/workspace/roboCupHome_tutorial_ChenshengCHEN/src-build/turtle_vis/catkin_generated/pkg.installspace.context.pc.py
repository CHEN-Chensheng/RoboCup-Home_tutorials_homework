# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/usr/local/include".split(';') if "/usr/local/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;rospy;std_msgs;tf;tf_conversions;visualization_msgs;message_run".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lturtle_vis".split(';') if "-lturtle_vis" != "" else []
PROJECT_NAME = "turtle_vis"
PROJECT_SPACE_DIR = "/usr/local"
PROJECT_VERSION = "0.0.0"
