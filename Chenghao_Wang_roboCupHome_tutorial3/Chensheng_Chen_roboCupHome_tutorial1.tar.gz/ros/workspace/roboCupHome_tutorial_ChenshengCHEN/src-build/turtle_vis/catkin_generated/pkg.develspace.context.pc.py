# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/chenshengchen/ros/workspace/roboCupHome_tutorial_ChenshengCHEN/src-build/devel/include;/home/chenshengchen/ros/workspace/roboCupHome_tutorial_ChenshengCHEN/src/turtle_vis/include".split(';') if "/home/chenshengchen/ros/workspace/roboCupHome_tutorial_ChenshengCHEN/src-build/devel/include;/home/chenshengchen/ros/workspace/roboCupHome_tutorial_ChenshengCHEN/src/turtle_vis/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;rospy;std_msgs;tf;tf_conversions;visualization_msgs;message_run".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lturtle_vis".split(';') if "-lturtle_vis" != "" else []
PROJECT_NAME = "turtle_vis"
PROJECT_SPACE_DIR = "/home/chenshengchen/ros/workspace/roboCupHome_tutorial_ChenshengCHEN/src-build/devel"
PROJECT_VERSION = "0.0.0"
