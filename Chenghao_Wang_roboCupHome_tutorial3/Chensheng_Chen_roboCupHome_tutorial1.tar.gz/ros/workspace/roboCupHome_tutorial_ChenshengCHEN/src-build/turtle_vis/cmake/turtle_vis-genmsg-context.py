# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/chenshengchen/ros/workspace/roboCupHome_tutorial_ChenshengCHEN/src/turtle_vis/msg/DesiredPose.msg"
services_str = "/home/chenshengchen/ros/workspace/roboCupHome_tutorial_ChenshengCHEN/src/turtle_vis/srv/send_desired_pose.srv"
pkg_name = "turtle_vis"
dependencies_str = "std_msgs"
langs = "gencpp;geneus;genlisp;gennodejs;genpy"
dep_include_paths_str = "turtle_vis;/home/chenshengchen/ros/workspace/roboCupHome_tutorial_ChenshengCHEN/src/turtle_vis/msg;std_msgs;/opt/ros/kinetic/share/std_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/kinetic/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
