
"use strict";

let send_desired_pose = require('./send_desired_pose.js')

module.exports = {
  send_desired_pose: send_desired_pose,
};
