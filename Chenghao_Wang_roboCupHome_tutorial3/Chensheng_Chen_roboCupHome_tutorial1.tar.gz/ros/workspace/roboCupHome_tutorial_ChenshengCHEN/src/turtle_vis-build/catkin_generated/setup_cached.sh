#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/chenshengchen/ros/workspace/roboCupHome_tutorial_ChenshengCHEN/src/turtle_vis-build/devel:$CMAKE_PREFIX_PATH"
export PATH="/opt/ros/kinetic/bin:/usr/lib/x86_64-linux-gnu/qt4/bin:/usr/bin:/home/chenshengchen/bin:/home/chenshengchen/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin"
export PWD="/home/chenshengchen/ros/workspace/roboCupHome_tutorial_ChenshengCHEN/src/turtle_vis-build"
export ROSLISP_PACKAGE_DIRECTORIES="/home/chenshengchen/ros/workspace/roboCupHome_tutorial_ChenshengCHEN/src/turtle_vis-build/devel/share/common-lisp"
export ROS_PACKAGE_PATH="/home/chenshengchen/ros/workspace/roboCupHome_tutorial_ChenshengCHEN/src/turtle_vis:$ROS_PACKAGE_PATH"